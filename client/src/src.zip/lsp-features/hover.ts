/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class HoverFeature implements ILspFeature {
	register(client: LanguageClient): vscode.Disposable[] {
		const caps = client.initializeResult?.capabilities;
		if (!caps?.hoverProvider) {
			return [];
		}

		const disposable = vscode.languages.registerHoverProvider(
			{ scheme: 'file' },
			{
				provideHover: async (doc, position, token) => {
					const res = await client.sendRequest<any>(
						'textDocument/hover',
						{
						textDocument: { uri: doc.uri.toString() },
						position: client.code2ProtocolConverter.asPosition(position)
						},
						token
					);
					return client.protocol2CodeConverter.asHover(res);
				}
			}
		);
		return [disposable];
	}
}
