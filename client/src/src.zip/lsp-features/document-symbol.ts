/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class DocumentSymbolFeature implements ILspFeature {
	register(client: LanguageClient): vscode.Disposable[] {
		const caps = client.initializeResult?.capabilities;
		if (!caps?.documentSymbolProvider) {
			return [];
		}

		const disposable = vscode.languages.registerDocumentSymbolProvider(
		{ scheme: 'file' },
		{
			provideDocumentSymbols: async (doc, token) => {
			const res = await client.sendRequest<any>(
				'textDocument/documentSymbol',
				{ textDocument: { uri: doc.uri.toString() } },
				token
			);
			return client.protocol2CodeConverter.asDocumentSymbols(res);
			}
		}
		);
		return [disposable];
	}
}
