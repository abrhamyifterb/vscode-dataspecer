/* eslint-disable @typescript-eslint/no-explicit-any */
// src/client/lspFeatures/definition.ts
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class DefinitionFeature implements ILspFeature {
	register(client: LanguageClient): vscode.Disposable[] {
		const caps = client.initializeResult?.capabilities;
		if (!caps?.definitionProvider) {
			return [];
		}

		const disposable = vscode.languages.registerDefinitionProvider(
			{ scheme: 'file' },
			{
				provideDefinition: async (doc, position, token) => {
					const res = await client.sendRequest<any>(
						'textDocument/definition',
						{
						textDocument: { uri: doc.uri.toString() },
						position: client.code2ProtocolConverter.asPosition(position)
						},
						token
					);
					return client.protocol2CodeConverter.asDefinitionResult(res);
				}
			}
		);

		return [disposable];
	}
}
