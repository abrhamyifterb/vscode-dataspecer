/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class CompletionFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    const comp = caps?.completionProvider;
    if (!comp) return [];

    const disposable = vscode.languages.registerCompletionItemProvider(
      { scheme: 'file' },
      {
		provideCompletionItems: async (doc, position, token, context) => {
			const res = await client.sendRequest<any>(
			  'textDocument/completion',
			  {
				textDocument: { uri: doc.uri.toString() },
				position: client.code2ProtocolConverter.asPosition(position),
				context: {
				  triggerKind: context.triggerKind,
				  triggerCharacter: context.triggerCharacter,
				}
			  },
			  token
			);
			return client.protocol2CodeConverter.asCompletionResult(res);
		  },
        resolveCompletionItem: comp.resolveProvider
          ? async (item, token) => {
              const res = await client.sendRequest<any>(
                'completionItem/resolve',
                client.code2ProtocolConverter.asCompletionItem(item),
                token
              );
              return client.protocol2CodeConverter.asCompletionItem(res);
            }
          : undefined
      },
      ...(comp.triggerCharacters ?? [])
    );

    return [disposable];
  }
}
