/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class ReferencesFeature implements ILspFeature {
	register(client: LanguageClient): vscode.Disposable[] {
		const caps = client.initializeResult?.capabilities;
		if (!caps?.referencesProvider) {
			return [];
		}

		const disposable = vscode.languages.registerReferenceProvider(
		{ scheme: 'file' },
		{
			provideReferences: async (doc, position, context, token) => {
				const res = await client.sendRequest<any>(
					'textDocument/references',
					{
					textDocument: { uri: doc.uri.toString() },
					position: client.code2ProtocolConverter.asPosition(position),
					context: { includeDeclaration: context.includeDeclaration }
					},
					token
				);
				return client.protocol2CodeConverter.asReferences(res);
			}
		}
		);

		return [disposable];
	}
}
