import { ILspFeature } from './ilsp-feature';
import { DefinitionFeature } from './definition';
import { ReferencesFeature } from './references';
import { HoverFeature } from './hover';
import { CallHierarchyFeature } from './call-hierarchy';
import { CompletionFeature } from './completion';
import { DocumentSymbolFeature } from './document-symbol';
import { InlayHintsFeature } from './inlay-hints';
import { SemanticTokensFeature } from './semantic-tokens';
import { WorkspaceSymbolFeature } from './workspace-symbol';
import { SignatureHelpFeature } from './signature-help';
import { TypeHierarchyFeature } from './type-hierarchy';

export const ALL_FEATURES: ILspFeature[] = [
  new DocumentSymbolFeature(),
  new WorkspaceSymbolFeature(),
  new DefinitionFeature(),
  new ReferencesFeature(),
  new HoverFeature(),
  new CompletionFeature(),
  new SignatureHelpFeature(),
  new TypeHierarchyFeature(),
  new CallHierarchyFeature(),
  new SemanticTokensFeature(),
  new InlayHintsFeature(),
];
