/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class InlayHintsFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    if (!caps?.inlayHintProvider) return [];

    const disposable = vscode.languages.registerInlayHintsProvider(
      { scheme: 'file' },
      {
        provideInlayHints: async (doc, range, token) => {
          const res = await client.sendRequest<any>(
            'textDocument/inlayHint',
            {
              textDocument: { uri: doc.uri.toString() },
              range: client.code2ProtocolConverter.asRange(range)
            },
            token
          );
          return client.protocol2CodeConverter.asInlayHints(res);
        }
      }
    );

    return [disposable];
  }
}
