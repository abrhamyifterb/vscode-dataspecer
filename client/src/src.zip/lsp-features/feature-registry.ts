import type { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class FeatureRegistry {
	private features: ILspFeature[] = [];
	add(feature: ILspFeature) { 
		this.features.push(feature); 
		return this; 
	}

	async registerAll(client: LanguageClient) {
		for (const f of this.features) {
			await f.register(client);
		}
	}
}
