/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class TypeHierarchyFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    if (!caps?.typeHierarchyProvider) return [];

    const disposable = vscode.languages.registerTypeHierarchyProvider(
      { scheme: 'file' },
      {
        prepareTypeHierarchy: async (doc, position, token) => {
          const res = await client.sendRequest<any>(
            'textDocument/prepareTypeHierarchy',
            {
              textDocument: { uri: doc.uri.toString() },
              position: client.code2ProtocolConverter.asPosition(position)
            },
            token
          );
          return client.protocol2CodeConverter.asTypeHierarchyItems(res);
        },
        provideTypeHierarchySupertypes: async (item, token) => {
          const res = await client.sendRequest<any>(
            'typeHierarchy/supertypes',
            client.code2ProtocolConverter.asTypeHierarchyItem(item),
            token
          );
          return client.protocol2CodeConverter.asTypeHierarchyItems(res);
        },
        provideTypeHierarchySubtypes: async (item, token) => {
          const res = await client.sendRequest<any>(
            'typeHierarchy/subtypes',
            client.code2ProtocolConverter.asTypeHierarchyItem(item),
            token
          );
          return client.protocol2CodeConverter.asTypeHierarchyItems(res);
        }
      }
    );

    return [disposable];
  }
}
