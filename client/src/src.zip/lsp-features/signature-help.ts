/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class SignatureHelpFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    const sh = caps?.signatureHelpProvider;
    if (!sh) return [];

    const disposable = vscode.languages.registerSignatureHelpProvider(
		{ scheme: 'file' },
		{
			provideSignatureHelp: async (doc, position, token, context) => {
				const res = await client.sendRequest<any>(
				'textDocument/signatureHelp',
				{
					textDocument: { uri: doc.uri.toString() },
					position: client.code2ProtocolConverter.asPosition(position),
					context: {
						triggerKind: context.triggerKind,
						triggerCharacter: context.triggerCharacter,
						isRetrigger: context.isRetrigger,
						activeSignatureHelp: context.activeSignatureHelp
							? {
								signatures: context.activeSignatureHelp.signatures.map(sig => ({
									label: sig.label,
									documentation: typeof sig.documentation === 'string' ? sig.documentation : sig.documentation?.value,
									parameters: sig.parameters?.map(param => ({
										label: typeof param.label === 'string' ? param.label : param.label,
										documentation: typeof param.documentation === 'string' ? param.documentation : param.documentation?.value,
									})),
								})),
								activeSignature: context.activeSignatureHelp.activeSignature,
								activeParameter: context.activeSignatureHelp.activeParameter,
							}
							: undefined,
					}
				},
				token
				);
				return client.protocol2CodeConverter.asSignatureHelp(res);
			}		  
    	},
    	...(sh.triggerCharacters ?? [])
    );

    return [disposable];
  }
}
