/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class CallHierarchyFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    if (!caps?.callHierarchyProvider) return [];

    const disposable = vscode.languages.registerCallHierarchyProvider(
      { scheme: 'file' },
      {
        prepareCallHierarchy: async (doc, position, token) => {
          const res = await client.sendRequest<any>(
            'textDocument/prepareCallHierarchy',
            {
              textDocument: { uri: doc.uri.toString() },
              position: client.code2ProtocolConverter.asPosition(position)
            },
            token
          );
          return client.protocol2CodeConverter.asCallHierarchyItems(res);
        },
        provideCallHierarchyIncomingCalls: async (item, token) => {
          const res = await client.sendRequest<any>(
            'callHierarchy/incomingCalls',
            client.code2ProtocolConverter.asCallHierarchyItem(item),
            token
          );
          return client.protocol2CodeConverter.asCallHierarchyIncomingCalls(res);
        },
        provideCallHierarchyOutgoingCalls: async (item, token) => {
          const res = await client.sendRequest<any>(
            'callHierarchy/outgoingCalls',
            client.code2ProtocolConverter.asCallHierarchyItem(item),
            token
          );
          return client.protocol2CodeConverter.asCallHierarchyOutgoingCalls(res);
        }
      }
    );

    return [disposable];
  }
}
