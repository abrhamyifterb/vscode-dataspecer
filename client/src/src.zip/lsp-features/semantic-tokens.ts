/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class SemanticTokensFeature implements ILspFeature {
  register(client: LanguageClient): vscode.Disposable[] {
    const caps = client.initializeResult?.capabilities;
    const stp = caps?.semanticTokensProvider;
    if (!stp) return [];

    const legend = new vscode.SemanticTokensLegend(
      stp.legend.tokenTypes,
      stp.legend.tokenModifiers
    );

    const docProv = vscode.languages.registerDocumentSemanticTokensProvider(
      { scheme: 'file' },
      {
        provideDocumentSemanticTokens: async (doc, token) => {
          const res = await client.sendRequest<any>(
            'textDocument/semanticTokens/full',
            { textDocument: { uri: doc.uri.toString() } },
            token
          );
          return new vscode.SemanticTokens(new Uint32Array(res.data));
        }
      },
      legend
    );

    return [docProv];
  }
}
