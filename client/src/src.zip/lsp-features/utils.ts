import type { LanguageClient } from 'vscode-languageclient/node';
import * as vscode from 'vscode';

export function asTextDoc(doc: vscode.TextDocument) {
	return { uri: doc.uri.toString() };
}

export function asPos(client: LanguageClient, pos: vscode.Position) {
	return client.code2ProtocolConverter.asPosition(pos);
}

export function isCapEnabled<T>(cap: T | undefined): cap is T {
	return !!cap;
}