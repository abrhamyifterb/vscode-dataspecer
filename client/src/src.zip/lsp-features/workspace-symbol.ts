/* eslint-disable @typescript-eslint/no-explicit-any */
import * as vscode from 'vscode';
import { LanguageClient } from 'vscode-languageclient/node';
import { ILspFeature } from './ilsp-feature';

export class WorkspaceSymbolFeature implements ILspFeature {
	register(client: LanguageClient): vscode.Disposable[] {
		const caps = client.initializeResult?.capabilities;
		if (!caps?.workspaceSymbolProvider) {
			return [];
		}

		const disposable = vscode.languages.registerWorkspaceSymbolProvider({
			provideWorkspaceSymbols: async (query, token) => {
				const res = await client.sendRequest<any>(
					'workspace/symbol',
					{ query },
					token
				);
				return client.protocol2CodeConverter.asSymbolTags(res);
			}
		});

		return [disposable];
	}
}
