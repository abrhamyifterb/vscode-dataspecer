import type { LanguageClient } from 'vscode-languageclient/node';
import type { Disposable } from 'vscode';

export interface ILspFeature {
	register(client: LanguageClient): Disposable[] | Promise<Disposable[]>;
}
