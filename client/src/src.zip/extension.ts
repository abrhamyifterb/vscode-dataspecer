/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */

import * as path from 'path';
import { workspace, ExtensionContext } from 'vscode';
import * as vscode from 'vscode';

import {
	LanguageClient,
	LanguageClientOptions,
	ServerOptions,
	TransportKind
} from 'vscode-languageclient/node';
import { FileSpecScanner } from './services/data/file-spec-scanner';
import { TurtleSpecParser } from './services/data/ttl-spec-parser';
import { LruSpecCache } from './services/data/lru-spec-cache';
import { SpecManager } from './services/data/spec-manager';
import { CodeGenerator } from './services/code-generator/code-generator';
import { ALL_FEATURES } from './lsp-features/register-all';

let client: LanguageClient;

export async function activate(context: ExtensionContext) {
	// The server is implemented in node
	const serverModule = context.asAbsolutePath(
		path.join('server', 'out', 'server.js')
	);

	// If the extension is launched in debug mode then the debug server options are used
	// Otherwise the run options are used
	const serverOptions: ServerOptions = {
		run: { module: serverModule, transport: TransportKind.ipc },
		debug: {
			module: serverModule,
			transport: TransportKind.ipc,
		}
	};

	// Options to control the language client
	const clientOptions: LanguageClientOptions = {
		// Register the server for plain text documents
		documentSelector: [{ scheme: 'file', language: 'plaintext' }],
		synchronize: {
			// Notify the server about file changes to '.clientrc files contained in the workspace
			fileEvents: workspace.createFileSystemWatcher('**/.clientrc')
		}
	};

	// Create the language client and start the client.
	client = new LanguageClient(
		'languageServerExample',
		'Language Server Example',
		serverOptions,
		clientOptions
	);

	const scannerr = new FileSpecScanner();
	const parser  = new TurtleSpecParser();
	const cache   = new LruSpecCache();
	const manager = new SpecManager([scannerr], parser, cache);

	context.subscriptions.push(
		vscode.commands.registerCommand('dataspecer.reloadSpecs', async () => {
			const models = await manager.loadAll();
			console.dir(models[0]);
			console.dir(models[0].profiles[0]);
			console.dir(models[0].profiles[0].properties);
			vscode.window.showInformationMessage(`Loaded ${models.length} DSV models`);
		})
	);

	context.subscriptions.push(
		vscode.commands.registerCommand('dataspecer.generateCode', async () => {
			const models = await manager.loadAll();
			const generator = new CodeGenerator(context.extensionPath + '/out');
			const files = await generator.generate(models);
		
			for (const [filePath, content] of files) {
				await vscode.workspace.fs.writeFile(
					vscode.Uri.file(filePath),
					Buffer.from(content, 'utf8')
				);
			}
			vscode.window.showInformationMessage('✅ Code generated for all DSV profiles');
		})
	);
	
	const disposables = (await Promise.all(ALL_FEATURES.map(f => f.register(client)))).flat();
	context.subscriptions.push(...disposables);

	// Start the client. This will also launch the server
	client.start();
}

export function deactivate(): Thenable<void> | undefined {
	if (!client) {
		return undefined;
	}
	return client.stop();
}
