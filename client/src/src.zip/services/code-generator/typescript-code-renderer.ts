// import { DataStructure } from '../../utils/data-structure';
// import { ILanguageRenderer } from '../interfaces/ilanguage-renderer';

import { ClassProfile } from '../dataspecer/dsv-model';

// export class TypeScriptRenderer implements ILanguageRenderer {
// 	outDirName = 'typescript';
// 	extension  = 'ts';

// 	render(ds: DataStructure): string {
// 		const lines: string[] = [];
// 		lines.push(`/**`);
// 		for (const [lang, txt] of Object.entries(ds.prefLabel)) {
// 			lines.push(` * [${lang}] ${txt}`);
// 		}
// 		if (ds.definition['']) {
// 			lines.push(` * ${ds.definition['']}`);
// 		}
// 		lines.push(` */`);
// 		lines.push(`export interface ${ds.technicalName} {`);
// 		for (const p of ds.properties) {
// 			const typeName = p.rangeDataTypeIri.length
// 				? mapXsdToTs(p.rangeDataTypeIri[0])
// 				// eslint-disable-next-line no-useless-escape
// 				: p.rangeClassIri[0].split(/[#\/]/).pop();
// 			const finalType = p.isMultiple ? `${typeName}[]` : typeName;
// 			const opt = p.isRequired ? '' : '?';
// 			lines.push(`  /** ${p.definition[''] || ''} */`);
// 			lines.push(`  ${p.technicalName}${opt}: ${finalType};`);
// 		}
// 		lines.push(`}`);
// 		return lines.join('\n');
// 	}
// }

// function mapXsdToTs(xsd: string): string {
// 	if (xsd?.endsWith('string'))  {return 'string';}
// 	if (xsd?.endsWith('decimal')) {return 'number';}
// 	return 'any';
// }




export function renderTypeScript(cls: ClassProfile): string {
	// eslint-disable-next-line no-useless-escape
	const name = cls.iri.split(/[#\/]/).pop()!;
	const lines: string[] = [];
  
	// Header doc
	lines.push(`/**`);
	if (cls.prefLabel['']) lines.push(` * ${cls.prefLabel['']}`);
	if (cls.definition[''])  lines.push(` * ${cls.definition['']}`);
	lines.push(` */`);
  
	// Interface signature
	lines.push(`export interface ${name} {`);
  
	for (const prop of cls.properties) {
	  // eslint-disable-next-line no-useless-escape
	  let propName = prop.iri.split(/[#\/]/).pop() || prop.iri; //prop.iri.split(/[#\/]/).pop()!;
	  propName = propName.split(".").pop() || propName;
	  const optional = prop.isRequired ? '' : '?';
  
	  // Determine TS type
	  let tsType = 'any';
	  if (prop?.dataType && (prop?.dataType as string)?.endsWith('string')) tsType = 'string';
	  else if ((prop?.dataType as string)?.endsWith('decimal')) tsType = 'number';
	  else if (prop.isMultiple) tsType = `${propName}[]`;
	  else tsType = (prop?.dataType as string)?.split('#').pop() || 'any';
  
	  // JSDoc per property

  
	  // Property line
	  lines.push(`  ${propName}${optional}: ${tsType};`);
	}
  
	lines.push(`}`);
	return lines.join('\n');
  }