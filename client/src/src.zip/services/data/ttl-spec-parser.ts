/* eslint-disable @typescript-eslint/no-explicit-any */
import type { Uri } from 'vscode';
import { ISpecParser } from '../interfaces/ispec-parser';
import { rdfToConceptualModel } from '../dataspecer/rdf-to-dsv';

export class TurtleSpecParser implements ISpecParser {
	async parse(uri: Uri, content: string) {
		return rdfToConceptualModel(content);
	}
}







// import type { Uri } from 'vscode';
// import { ISpecParser } from '../interfaces/ispec-parser';
// import { rdfToConceptualModel } from '../dataspecer/rdf-to-dsv';
// import { StructureProperty } from '../../utils/structure-property';
// import { DataStructure } from '../../utils/data-structure';

// export class TurtleSpecParser implements ISpecParser {
// 	async parse(uri: Uri, content: string): Promise<DataStructure[]> {
// 		const dsvModels = await rdfToConceptualModel(content);
	
// 		return dsvModels.map(m => ({
// 			iri: m?.iri,
// 			// eslint-disable-next-line no-useless-escape
// 			technicalName: m?.iri?.split(/[#\/]/).pop() || m?.iri,
// 			prefLabel: m?.profiles.reduce((acc, p) => Object.assign(acc, p.prefLabel), {} as Record<string,string>),
// 			definition: m?.profiles.reduce((acc, p) => Object.assign(acc, p.definition), {} as Record<string,string>),
// 			usageNote: m?.profiles.reduce((acc, p) => Object.assign(acc, p.usageNote), {} as Record<string,string>),
// 			cardinality: '1-1',
// 			profiles: undefined,
// 			requirementLevel: 0,
// 			properties: m?.profiles
// 			.filter(p => p?.$type.includes('class-profile'))
// 			.flatMap(cp => cp?.properties as any[])
// 			.map(p => {
// 				const prop: StructureProperty = {
// 					iri: p.iri,
// 					technicalName: p?.technicalName,
// 					prefLabel: { ...p?.prefLabel },
// 					definition: { ...p?.definition },
// 					usageNote: { ...p?.usageNote },
// 					cardinality: p?.cardinality,
// 					requirementLevel: p?.requirementLevel,
// 					rangeClassIri: (p as any)?.rangeClassIri || [],
// 					rangeDataTypeIri: (p as any)?.rangeDataTypeIri || [],
// 					profiledPropertyIri: p?.profileOfIri,
// 					reusesPropertyValue: p?.reusesPropertyValue || [],
// 					isMultiple: p.cardinality?.endsWith('n'),
// 					isRequired: p.cardinality?.startsWith('1'),
// 				};
// 				return prop;
// 			})
// 		}));
// 	}
// }