import { ClassProfile } from '../services/dataspecer/dsv-model';
import { ClassShape } from './ishapes';

export function classProfileToShape(cp: ClassProfile): ClassShape {
  return {
    iri: cp.iri,
    name: local(cp.iri),
    properties: cp.properties.map(p => ({
		iri: p.iri,
		name: local(p.iri),
		isRequired: (p.isRequired as boolean) ?? false,
		isMultiple: p.isMultiple as boolean ?? false,
		dataType: p.dataType as string,
    }))
  };
}
// eslint-disable-next-line no-useless-escape
const local = (iri: string) => iri.split(/[#\/]/).pop()!;
